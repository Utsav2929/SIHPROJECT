package com.aaks32173.sih2022new;

public class MsgModel {
    private String cnt;
    public String getCnt() {
        return cnt;
    }

    public void setCnt(String cnt) {
        this.cnt = cnt;
    }
    public MsgModel(String cnt) {
        this.cnt = cnt;
    }


}
