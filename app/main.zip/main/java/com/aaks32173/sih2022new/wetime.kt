package com.aaks32173.sih2022new

class wetime (val id: String?=null,val date: String?=null,  val description: String?=null,
             var status: String?=null)
{

}