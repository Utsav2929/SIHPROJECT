package com.aaks32173.sih2022new;

import java.util.ArrayList;

public interface QuantityListener {
    void onQuantityChange(ArrayList<String> arrayList);
}
