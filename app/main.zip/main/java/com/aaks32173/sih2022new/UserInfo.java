package com.aaks32173.sih2022new;

public class UserInfo {

    private String name,email,password,age,sssm_id,family_id,gender;

    public UserInfo(){

    }


    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }

    public String getage() {
        return age;
    }
    public void setage(String age) {
        this.age = age;
    }

    public String getSssm_id() {
        return sssm_id;
    }
    public void setSssm_id(String sssm_id) {
        this.sssm_id = sssm_id;
    }

    public String getFamily_id() {
        return family_id;
    }
    public void setFamily_id(String family_id) {
        this.family_id = family_id;
    }

    public String getGender() {
        return gender;
    }
    public void setGender(String gender) {
        this.gender = gender;
    }
}
