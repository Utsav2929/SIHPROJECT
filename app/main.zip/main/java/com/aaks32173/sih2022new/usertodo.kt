package com.aaks32173.sih2022new

class usertodo (val date: String?=null,val activity: String?=null,val intrest: String?=null,val progress: String?=null)
{

}