package com.aaks32173.sih2022new;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class workout extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_workout);
    }
}