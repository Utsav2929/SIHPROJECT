package com.aaks32173.sih2022new

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class sports : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sports)
    }
}