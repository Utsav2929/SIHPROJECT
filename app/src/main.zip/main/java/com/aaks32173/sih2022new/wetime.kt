package com.aaks32173.sih2022new

class wetime (val rank: String?=null,  val descripton: String?=null,
             var Status: String?=null)
{

}