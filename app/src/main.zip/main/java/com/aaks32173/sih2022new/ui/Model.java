package com.aaks32173.sih2022new.ui;

public class Model {


}
