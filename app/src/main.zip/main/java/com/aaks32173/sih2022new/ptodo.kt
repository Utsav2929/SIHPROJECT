package com.aaks32173.sih2022new

class ptodo (val date: String?=null, val title: String?=null, val descripton: String?=null,
             var ismarked: String?=null)
{

}