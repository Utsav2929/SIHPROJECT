package com.aaks32173.sih2022new.data

data class Message(val message: String, val id: String, val time: String)