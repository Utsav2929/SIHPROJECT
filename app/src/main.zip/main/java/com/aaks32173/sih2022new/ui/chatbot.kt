package com.aaks32173.sih2022new.ui

class chatbot(val mainindex: String?=null, val question: String?=null, val answer1: String?=null,
              val answer1index: String?=null, val answer2: String?=null,
              val answer2index: String?=null, val answer3: String?=null,
              val answer3index: String?=null) {
}