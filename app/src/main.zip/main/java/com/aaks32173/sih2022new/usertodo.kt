package com.aaks32173.sih2022new

class usertodo (val date: String?=null,val name: String?=null,val percent: String?=null,val intrest: String?=null,val ismarked: String?=null)
{

}